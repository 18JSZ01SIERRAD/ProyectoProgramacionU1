﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProyectoU1
{
    public partial class Form12 : Form
    {
        public Form12()
        {
            InitializeComponent();
        }

        private int l1, l2, l3, t;

        private void button1_Click(object sender, EventArgs e)
        {
            l1 = Convert.ToInt32(textBox1.Text);
            l2 = Convert.ToInt32(textBox2.Text);
            l3 = Convert.ToInt32(textBox4.Text);

            t = l1 + l2 + (l3*2);

            label2.Text = t.ToString();
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }
    }
}
