﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProyectoU1
{
    public partial class Form4 : Form
    {
        public Form4()
        {
            InitializeComponent();
        }
        private int l, a, t;

        private void triánguloEquilateroToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            l = Convert.ToInt32(textBox1.Text);
            a = Convert.ToInt32(textBox2.Text);

            t = 2*(l+a);

            label2.Text = t.ToString();
        }
    }
}
