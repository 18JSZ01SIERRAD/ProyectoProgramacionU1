﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProyectoU1
{
    public partial class Form21 : Form
    {
        public Form21()
        {
            InitializeComponent();
        }

        private int l, t;

        private void button1_Click(object sender, EventArgs e)
        {
            l = Convert.ToInt32(textBox1.Text);

            t = 12 * l;

            label2.Text = t.ToString();
        }
    }
}
