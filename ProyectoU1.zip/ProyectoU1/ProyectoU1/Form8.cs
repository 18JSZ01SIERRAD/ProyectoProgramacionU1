﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProyectoU1
{
    public partial class Form8 : Form
    {
        public Form8()
        {
            InitializeComponent();
        }

        private double l1, l2, t;

        private void button1_Click(object sender, EventArgs e)
        {
            l1 = Convert.ToDouble(textBox1.Text);
            l2 = Convert.ToDouble(textBox2.Text);

            t = l1 + l2 + Math.Sqrt((l1*l1)+(l2*l2));

            label2.Text = t.ToString();
        }
    }
}
