﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProyectoU1
{
    public partial class Form18 : Form
    {
        public Form18()
        {
            InitializeComponent();
        }

        private double se1, se2, t;
        private void button1_Click(object sender, EventArgs e)
        {
            se1 = Convert.ToDouble(textBox1.Text);
            se2 = Convert.ToDouble(textBox2.Text);

            t = (3.14) * (3 * (se1 + se2) - Math.Sqrt((3*se1+se2)*(se1+se2*3)));

            label2.Text = t.ToString();
        }
    }
}
