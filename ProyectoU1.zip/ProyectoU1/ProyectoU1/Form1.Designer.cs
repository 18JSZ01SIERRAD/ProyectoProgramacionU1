﻿namespace ProyectoU1
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.perímetrosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cuadradoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.circuloToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.form5ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.form6ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.form7ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.form8ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.form9ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.form10ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.fOrm11ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.form12ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.form13ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.form14ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.form15ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.form16ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.form17ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.form18ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.form19ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.form20ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.form21ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.form522ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.panel1.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.menuStrip1);
            this.panel1.Location = new System.Drawing.Point(-3, -4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(857, 921);
            this.panel1.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft PhagsPa", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.label1.Location = new System.Drawing.Point(311, 284);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(213, 79);
            this.label1.TabIndex = 1;
            this.label1.Text = "MENÚ";
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.perímetrosToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(857, 46);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // perímetrosToolStripMenuItem
            // 
            this.perímetrosToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.cuadradoToolStripMenuItem,
            this.circuloToolStripMenuItem,
            this.form5ToolStripMenuItem,
            this.form6ToolStripMenuItem,
            this.form7ToolStripMenuItem,
            this.form8ToolStripMenuItem,
            this.form9ToolStripMenuItem,
            this.form10ToolStripMenuItem,
            this.fOrm11ToolStripMenuItem,
            this.form12ToolStripMenuItem,
            this.form13ToolStripMenuItem,
            this.form14ToolStripMenuItem,
            this.form15ToolStripMenuItem,
            this.form16ToolStripMenuItem,
            this.form17ToolStripMenuItem,
            this.form18ToolStripMenuItem,
            this.form19ToolStripMenuItem,
            this.form20ToolStripMenuItem,
            this.form21ToolStripMenuItem,
            this.form522ToolStripMenuItem});
            this.perímetrosToolStripMenuItem.Font = new System.Drawing.Font("Segoe UI", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.perímetrosToolStripMenuItem.Name = "perímetrosToolStripMenuItem";
            this.perímetrosToolStripMenuItem.Size = new System.Drawing.Size(173, 42);
            this.perímetrosToolStripMenuItem.Text = "Perímetros";
            // 
            // cuadradoToolStripMenuItem
            // 
            this.cuadradoToolStripMenuItem.Name = "cuadradoToolStripMenuItem";
            this.cuadradoToolStripMenuItem.Size = new System.Drawing.Size(224, 42);
            this.cuadradoToolStripMenuItem.Text = "Form2";
            this.cuadradoToolStripMenuItem.Click += new System.EventHandler(this.cuadradoToolStripMenuItem_Click);
            // 
            // circuloToolStripMenuItem
            // 
            this.circuloToolStripMenuItem.Name = "circuloToolStripMenuItem";
            this.circuloToolStripMenuItem.Size = new System.Drawing.Size(224, 42);
            this.circuloToolStripMenuItem.Text = "Form4";
            this.circuloToolStripMenuItem.Click += new System.EventHandler(this.circuloToolStripMenuItem_Click);
            // 
            // form5ToolStripMenuItem
            // 
            this.form5ToolStripMenuItem.Name = "form5ToolStripMenuItem";
            this.form5ToolStripMenuItem.Size = new System.Drawing.Size(224, 42);
            this.form5ToolStripMenuItem.Text = "Form5";
            this.form5ToolStripMenuItem.Click += new System.EventHandler(this.form5ToolStripMenuItem_Click);
            // 
            // form6ToolStripMenuItem
            // 
            this.form6ToolStripMenuItem.Name = "form6ToolStripMenuItem";
            this.form6ToolStripMenuItem.Size = new System.Drawing.Size(224, 42);
            this.form6ToolStripMenuItem.Text = "Form6";
            this.form6ToolStripMenuItem.Click += new System.EventHandler(this.form6ToolStripMenuItem_Click);
            // 
            // form7ToolStripMenuItem
            // 
            this.form7ToolStripMenuItem.Name = "form7ToolStripMenuItem";
            this.form7ToolStripMenuItem.Size = new System.Drawing.Size(224, 42);
            this.form7ToolStripMenuItem.Text = "Form7";
            this.form7ToolStripMenuItem.Click += new System.EventHandler(this.form7ToolStripMenuItem_Click);
            // 
            // form8ToolStripMenuItem
            // 
            this.form8ToolStripMenuItem.Name = "form8ToolStripMenuItem";
            this.form8ToolStripMenuItem.Size = new System.Drawing.Size(224, 42);
            this.form8ToolStripMenuItem.Text = "Form8";
            this.form8ToolStripMenuItem.Click += new System.EventHandler(this.form8ToolStripMenuItem_Click);
            // 
            // form9ToolStripMenuItem
            // 
            this.form9ToolStripMenuItem.Name = "form9ToolStripMenuItem";
            this.form9ToolStripMenuItem.Size = new System.Drawing.Size(224, 42);
            this.form9ToolStripMenuItem.Text = "Form9";
            this.form9ToolStripMenuItem.Click += new System.EventHandler(this.form9ToolStripMenuItem_Click);
            // 
            // form10ToolStripMenuItem
            // 
            this.form10ToolStripMenuItem.Name = "form10ToolStripMenuItem";
            this.form10ToolStripMenuItem.Size = new System.Drawing.Size(224, 42);
            this.form10ToolStripMenuItem.Text = "Form10";
            this.form10ToolStripMenuItem.Click += new System.EventHandler(this.form10ToolStripMenuItem_Click);
            // 
            // fOrm11ToolStripMenuItem
            // 
            this.fOrm11ToolStripMenuItem.Name = "fOrm11ToolStripMenuItem";
            this.fOrm11ToolStripMenuItem.Size = new System.Drawing.Size(224, 42);
            this.fOrm11ToolStripMenuItem.Text = "Form11";
            this.fOrm11ToolStripMenuItem.Click += new System.EventHandler(this.fOrm11ToolStripMenuItem_Click);
            // 
            // form12ToolStripMenuItem
            // 
            this.form12ToolStripMenuItem.Name = "form12ToolStripMenuItem";
            this.form12ToolStripMenuItem.Size = new System.Drawing.Size(224, 42);
            this.form12ToolStripMenuItem.Text = "Form12";
            this.form12ToolStripMenuItem.Click += new System.EventHandler(this.form12ToolStripMenuItem_Click);
            // 
            // form13ToolStripMenuItem
            // 
            this.form13ToolStripMenuItem.Name = "form13ToolStripMenuItem";
            this.form13ToolStripMenuItem.Size = new System.Drawing.Size(224, 42);
            this.form13ToolStripMenuItem.Text = "Form13";
            this.form13ToolStripMenuItem.Click += new System.EventHandler(this.form13ToolStripMenuItem_Click);
            // 
            // form14ToolStripMenuItem
            // 
            this.form14ToolStripMenuItem.Name = "form14ToolStripMenuItem";
            this.form14ToolStripMenuItem.Size = new System.Drawing.Size(224, 42);
            this.form14ToolStripMenuItem.Text = "Form14";
            this.form14ToolStripMenuItem.Click += new System.EventHandler(this.form14ToolStripMenuItem_Click);
            // 
            // form15ToolStripMenuItem
            // 
            this.form15ToolStripMenuItem.Name = "form15ToolStripMenuItem";
            this.form15ToolStripMenuItem.Size = new System.Drawing.Size(224, 42);
            this.form15ToolStripMenuItem.Text = "Form15";
            this.form15ToolStripMenuItem.Click += new System.EventHandler(this.form15ToolStripMenuItem_Click);
            // 
            // form16ToolStripMenuItem
            // 
            this.form16ToolStripMenuItem.Name = "form16ToolStripMenuItem";
            this.form16ToolStripMenuItem.Size = new System.Drawing.Size(224, 42);
            this.form16ToolStripMenuItem.Text = "Form16";
            this.form16ToolStripMenuItem.Click += new System.EventHandler(this.form16ToolStripMenuItem_Click);
            // 
            // form17ToolStripMenuItem
            // 
            this.form17ToolStripMenuItem.Name = "form17ToolStripMenuItem";
            this.form17ToolStripMenuItem.Size = new System.Drawing.Size(224, 42);
            this.form17ToolStripMenuItem.Text = "Form17";
            this.form17ToolStripMenuItem.Click += new System.EventHandler(this.form17ToolStripMenuItem_Click);
            // 
            // form18ToolStripMenuItem
            // 
            this.form18ToolStripMenuItem.Name = "form18ToolStripMenuItem";
            this.form18ToolStripMenuItem.Size = new System.Drawing.Size(224, 42);
            this.form18ToolStripMenuItem.Text = "Form18";
            this.form18ToolStripMenuItem.Click += new System.EventHandler(this.form18ToolStripMenuItem_Click);
            // 
            // form19ToolStripMenuItem
            // 
            this.form19ToolStripMenuItem.Name = "form19ToolStripMenuItem";
            this.form19ToolStripMenuItem.Size = new System.Drawing.Size(224, 42);
            this.form19ToolStripMenuItem.Text = "Form19";
            this.form19ToolStripMenuItem.Click += new System.EventHandler(this.form19ToolStripMenuItem_Click);
            // 
            // form20ToolStripMenuItem
            // 
            this.form20ToolStripMenuItem.Name = "form20ToolStripMenuItem";
            this.form20ToolStripMenuItem.Size = new System.Drawing.Size(224, 42);
            this.form20ToolStripMenuItem.Text = "Form20";
            this.form20ToolStripMenuItem.Click += new System.EventHandler(this.form20ToolStripMenuItem_Click);
            // 
            // form21ToolStripMenuItem
            // 
            this.form21ToolStripMenuItem.Name = "form21ToolStripMenuItem";
            this.form21ToolStripMenuItem.Size = new System.Drawing.Size(224, 42);
            this.form21ToolStripMenuItem.Text = "Form21";
            this.form21ToolStripMenuItem.Click += new System.EventHandler(this.form21ToolStripMenuItem_Click);
            // 
            // form522ToolStripMenuItem
            // 
            this.form522ToolStripMenuItem.Name = "form522ToolStripMenuItem";
            this.form522ToolStripMenuItem.Size = new System.Drawing.Size(224, 42);
            this.form522ToolStripMenuItem.Text = "Form22";
            this.form522ToolStripMenuItem.Click += new System.EventHandler(this.form522ToolStripMenuItem_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(848, 743);
            this.Controls.Add(this.panel1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = "Form1";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem perímetrosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cuadradoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem circuloToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem form5ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem form6ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem form7ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem form8ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem form9ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem form10ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem fOrm11ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem form12ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem form13ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem form14ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem form15ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem form16ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem form17ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem form18ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem form19ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem form20ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem form21ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem form522ToolStripMenuItem;
    }
}

