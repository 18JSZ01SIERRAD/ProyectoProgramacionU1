﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProyectoU1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void cuadradoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form2 v1 = new Form2();
            v1.Show();
            this.Hide();
        }

        private void circuloToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form4 v2 = new Form4();
            v2.Show();
            this.Hide();
        }

        private void form5ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form5 v3 = new Form5();
            v3.Show();
            this.Hide();
        }

        private void form6ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form6 v4 = new Form6();
            v4.Show();
            this.Hide();
        }

        private void form7ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form7 v5 = new Form7();
            v5.Show();
            this.Hide();
        }

        private void form8ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form8 v2 = new Form8();
            v2.Show();
            this.Hide();
        }

        private void form9ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form9 v2 = new Form9();
            v2.Show();
            this.Hide();
        }

        private void form10ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form10 v2 = new Form10();
            v2.Show();
            this.Hide();
        }

        private void fOrm11ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form11 v2 = new Form11();
            v2.Show();
            this.Hide();
        }

        private void form12ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form12 v2 = new Form12();
            v2.Show();
            this.Hide();
        }

        private void form13ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form13 v2 = new Form13();
            v2.Show();
            this.Hide();
        }

        private void form14ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form14 v2 = new Form14();
            v2.Show();
            this.Hide();
        }

        private void form15ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form15 v2 = new Form15();
            v2.Show();
            this.Hide();
        }

        private void form16ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form16 v2 = new Form16();
            v2.Show();
            this.Hide();
        }

        private void form17ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form17 v2 = new Form17();
            v2.Show();
            this.Hide();
        }

        private void form18ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form18 v2 = new Form18();
            v2.Show();
            this.Hide();
        }

        private void form19ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form19 v2 = new Form19();
            v2.Show();
            this.Hide();
        }

        private void form20ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form20 v2 = new Form20();
            v2.Show();
            this.Hide();
        }

        private void form21ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form21 v2 = new Form21();
            v2.Show();
            this.Hide();
        }

        private void form522ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form22 v2 = new Form22();
            v2.Show();
            this.Hide();
        }
    }
}
