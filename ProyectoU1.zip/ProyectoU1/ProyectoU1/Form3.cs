﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProyectoU1
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        private double r, P;

        private void cuadradoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form2 v1 = new Form2();
            v1.Show();
            this.Hide();
        }

        private void circuloToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form1 v0 = new Form1();
            v0.Show();
            this.Hide();
        }

        private void rectánguloToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form4 v2 = new Form4();
            v2.Show();
            this.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            r = Convert.ToInt32(textBox1.Text);
            P = 2 * (3.14) * r;
            label2.Text = P.ToString();
        }
    }
}
